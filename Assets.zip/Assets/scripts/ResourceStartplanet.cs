﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResourceStartplanet : MonoBehaviour {

    public static int Resource;
    public static int ResourceLeft;
    public static int ResourceGain;

    [SerializeField]
    int resources_left = 5;

    [SerializeField]
    int resources_gaining = 1;
    
    void Start()
    {
        ResourceLeft += resources_left;
        ResourceGain += resources_gaining;
    }
    void Update()
    {

    }
    
}