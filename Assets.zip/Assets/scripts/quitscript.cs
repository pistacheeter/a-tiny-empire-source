﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class quitscript : MonoBehaviour {

	public void pressed()
    {
        Application.Quit();
        
    }
}
