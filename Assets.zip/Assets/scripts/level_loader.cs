﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class level_loader : MonoBehaviour {

    public void LoadLevel(string level)
    {
        SceneManager.LoadScene(level);
    }
    public void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
