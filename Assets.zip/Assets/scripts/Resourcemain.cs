﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Resourcemain : MonoBehaviour {

    public static int Resources = 1;
    public static int ResourcesL;
    public static int ResourcesG;
    

    public Text resources;
    public Text resources2;
    public Text resources3;

    public Canvas WinCanvas;
    public Canvas LevelCanvas;

    public GameObject AI;

    public AudioSource WonSound;
    public AudioSource WonSound2;

    public GameObject Level;
    GameObject[] g;

    GameObject[] G;

    GameObject[] e;

    public static bool gaining = true;
    public static bool Won = false;

    public float period = 0.0f;

    void FixedUpdate()
    {
        g = GameObject.FindGameObjectsWithTag("EnemyPlanet");

        int index = g.Length;

        if (index <= 0)
        {
            Won = true;
        }

        if (AIplanets.resourcesL <= 0 && AIplanets.resources <= 0 && ResourcesL <= 0 && Resources <= 0)
        {
            G = GameObject.FindGameObjectsWithTag("EnemyPlanet");
            e = GameObject.FindGameObjectsWithTag("FriendlyPlanet");

            if(G.Length > e.Length)
            {
                AI.GetComponent<AIplanets>().Lose = true;
            }
            if(e.Length > G.Length)
            {
                Won = true;
            }
            
        }

        if (Won == true)
        {
            WonSound.Play();
            WonSound.Play();
            WonSound.Play();
            WonSound2.Play();

            WinCanvas.gameObject.SetActive(true);
            LevelCanvas.gameObject.SetActive(false);
            Level.SetActive(false);
            Won = false;
            gaining = true;
            enemyPlanetScript.ResourceLeft = 0;
            enemyPlanetScript.Resource = 0;
            enemyPlanetScript.ResourceGain = 0;
            Resources = 0;
            ResourcesL = 0;
            ResourcesG = 0;
        }

    }

    void Update()
    {
        ResourcesL = enemyPlanetScript.ResourceLeft;
        ResourcesG = enemyPlanetScript.ResourceGain;

        if (Input.GetButtonDown("Cancel"))
        {
            
            Won = false;
            gaining = true;
            enemyPlanetScript.ResourceLeft = 0;
            enemyPlanetScript.Resource = 0;
            enemyPlanetScript.ResourceGain = 0;
            Resources = 0;
            ResourcesL = 0;
            ResourcesG = 0;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
        if (Input.GetKeyDown("a"))
        {
            WonSound.Play();
            WonSound.Play();
            WonSound.Play();
            WonSound2.Play();
            
            Won = false;
            gaining = true;
            enemyPlanetScript.ResourceLeft = 0;
            enemyPlanetScript.Resource = 0;
            enemyPlanetScript.ResourceGain = 0;
            Resources = 0;
            ResourcesL = 0;
            ResourcesG = 0;

            if (SceneManager.GetActiveScene().name == "level_1")
            {
                SceneManager.LoadScene("level_2");
            }
            if (SceneManager.GetActiveScene().name == "level_2")
            {
                SceneManager.LoadScene("level_3");
            }
            if (SceneManager.GetActiveScene().name == "level_3")
            {
                SceneManager.LoadScene("level_4");
            }
            if (SceneManager.GetActiveScene().name == "level_4")
            {
                SceneManager.LoadScene("startscene");
            }
        }

        if (period > 1)
        {
            if(ResourcesL > 0) { 
                Resources = Resources += ResourcesG;
                ResourcesL -= ResourcesG;
                enemyPlanetScript.ResourceLeft -= enemyPlanetScript.ResourceGain;
                gaining = true;
            }
            
            resources3.text = Resources.ToString();
            resources.text = ResourcesL.ToString();
            resources2.text = ResourcesG.ToString();

            //Do Stuff^
            period = 0;
        }
        period += UnityEngine.Time.deltaTime;
    }

}
