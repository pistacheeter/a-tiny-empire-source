﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class enemyPlanetScript : MonoBehaviour {

    public static int Resource;
    public static int ResourceLeft;
    public static int ResourceGain;

    public int size = 5;

    public int resources = 10;
    public int resourcesG = 1;

    public int starthealth = 10;
    public int health = 0;

    public AudioSource lose;
    public AudioSource get;

    bool set = false;
    bool resourcesgained = false;

    public Sprite green;
    public Sprite red;
    public Sprite gray;

    public AIplanets AI;
    bool resourcesgainedAI = false;

    public Text healthtext;

    public bool badgood = false;
    public bool neutral = false;

    public static bool badgoodlasthit = false;

    void Update()
    {

        //health = health;

        healthtext.text = health.ToString();

        if (health <= 0)
        {



            SpriteRenderer s = this.gameObject.GetComponent<SpriteRenderer>();

            badgood = !badgood;

            if (neutral)
            {
                if(badgoodlasthit == false)
                {
                    badgood = false;
                }
                if (badgoodlasthit == true)
                {
                    badgood = true;
                }
            }

            if(badgood == false && !neutral) {
                get.Play();
                s.sprite = green;
                this.tag = "FriendlyPlanet";

                if(resourcesgained == false) {
                    ResourceLeft += resources;
                    ResourceGain += resourcesG;

                    resourcesgained = true;
                }
                
            }
            if(badgood == true && !neutral) {
                lose.Play(); 
                s.sprite = red;
                this.tag = "EnemyPlanet";
                
                if (resourcesgainedAI == false)
                {
                    AIplanets.resourcesL += resources;
                    AI.resourcesG += resourcesG;

                    resourcesgainedAI = true;
                }

            }
            if (neutral)
            {
                s.sprite = gray;
                this.tag = "NeutralPlanet";

            }
            

            health = starthealth;
            //Destroy(gameObject);
        }
    }


}
