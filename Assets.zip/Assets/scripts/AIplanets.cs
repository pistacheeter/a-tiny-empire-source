﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIplanets : MonoBehaviour {

    public static int resources;
    public int resourcesG;
    public static int resourcesL;

    int tactic;

    GameObject[] g;

    public Canvas LoseCanvas;
    public Canvas LevelCanvas;
    public GameObject Level;

    [SerializeField]
    AudioSource LoseSound;

    [SerializeField]
    GameObject lightUnit;
    [SerializeField]
    GameObject mediumUnit;
    [SerializeField]
    GameObject heavyUnit;

    [SerializeField]
    Sendunit send;

    public float period = 0.0f;

    public bool Lose = false;

	void Start () {
        
    }
    void FixedUpdate()
    {
        g = GameObject.FindGameObjectsWithTag("FriendlyPlanet");

        int index = g.Length;

        if (index <= 0)
        {
            Lose = true;
        }
        if(Lose == true)
        {
            LoseSound.Play();
            LoseCanvas.gameObject.SetActive(true);
            LevelCanvas.gameObject.SetActive(false);
            Level.SetActive(false);
            Lose = false;
            
            enemyPlanetScript.ResourceLeft = 0;
            enemyPlanetScript.Resource = 0;
            enemyPlanetScript.ResourceGain = 0;
            resourcesL = 0;
            resourcesG = 0;
            resources = 0;
            Resourcemain.Resources = 0;
            Resourcemain.ResourcesL = 0;
            Resourcemain.ResourcesG = 0;
        }
    }
    void Update()
    {

        if(resources > 15)
        {
            if (period > 0.5)
            {

                



                tactic = Random.Range(1, 3);

                if (resources > 5)
                {
                    if (tactic == 1)
                        for (int i = 0; i < Random.Range(1, 3); i++)
                            send.SendUnitAI(lightUnit, this.transform);
                    if (tactic == 2)
                        for (int i = 0; i < Random.Range(1, 2); i++)
                            send.SendUnitAI(mediumUnit, this.transform);


                }

                if (resources > 10)
                {
                    if (tactic == 1)
                        for (int i = 0; i < Random.Range(1, 2); i++)
                            send.SendUnitAI(mediumUnit, this.transform);
                    if (tactic == 2)
                        for (int i = 0; i < Random.Range(6, 8); i++)
                            send.SendUnitAI(lightUnit, this.transform);
                }
                period = 0;
            }

            if (period > 1) { 
                if (resourcesL > 0)
            {
                resources = resources += resourcesG;
                resourcesL -= resourcesG;
                //enemyPlanetScript.ResourceLeft -= enemyPlanetScript.ResourceGain;
                //gaining = true;
            }
            }
        }

        if (resources < 15)
        {
            if (period > 1)
            {

                if (resourcesL > 0)
                {
                    resources = resources += resourcesG;
                    resourcesL -= resourcesG;
                    //enemyPlanetScript.ResourceLeft -= enemyPlanetScript.ResourceGain;
                    //gaining = true;
                }



                tactic = Random.Range(1, 5);

                if(resources  < 2)
                {
                    for (int i = 0; i < resources; i++)
                    {
                        send.SendUnitAI(lightUnit, this.transform);
                    }
                }

                if(resources < 5)
                {
                    if(tactic == 1)
                        for (int i = 0; i < Random.Range(1, 3); i++)
                            send.SendUnitAI(lightUnit, this.transform);
                    if(tactic == 2)
                        for (int i = 0; i < Random.Range(1, 2); i++)
                            send.SendUnitAI(mediumUnit, this.transform);
                    if(tactic == 3)
                            send.SendUnitAI(heavyUnit, this.transform);
                    if (tactic == 4) ;
                        
                }

                if (resources > 5)
                {
                    if (tactic == 1)
                        for (int i = 0; i < Random.Range(1, 3); i++)
                            send.SendUnitAI(lightUnit, this.transform);
                    if (tactic == 2)
                        for (int i = 0; i < Random.Range(1, 2); i++)
                            send.SendUnitAI(mediumUnit, this.transform);
                    if (tactic == 3)
                        for (int i = 0; i < Random.Range(1, 2); i++)
                            send.SendUnitAI(heavyUnit, this.transform);
                    if(tactic == 4)
                        send.SendUnitAI(lightUnit, this.transform);
                    
                }

                if (resources > 10)
                {
                    if (tactic == 1)
                        for (int i = 0; i < Random.Range(1, 4); i++)
                            send.SendUnitAI(mediumUnit, this.transform);
                    if (tactic == 2)
                        for (int i = 0; i < Random.Range(6, 8); i++)
                            send.SendUnitAI(lightUnit, this.transform);
                    if (tactic == 3)
                        for (int i = 0; i < Random.Range(1, 3); i++)
                            send.SendUnitAI(heavyUnit, this.transform);
                    if (tactic == 4)
                        for (int i = 0; i < Random.Range(2, 3); i++)
                            send.SendUnitAI(lightUnit, this.transform);

                }
                period = 0;
            }
        }
        period += UnityEngine.Time.deltaTime;

    }
}
