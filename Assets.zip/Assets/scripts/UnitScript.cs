﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitScript : MonoBehaviour {

    public unit unitd;
    public Transform target;
     GameObject planet;
     GameObject[] planeta;
    GameObject[] planetn;
    enemyPlanetScript enem;
    int index;

    public Transform trans;

    public AIplanets ai;

    public bool enemy = false;


    public bool Damage = true;

    void Start()
    {
        if (enemy) { 
            this.transform.SetParent(trans, false);
            ai = this.GetComponentInParent<AIplanets>();
        }
        unitd = this.GetComponent<unit>();
    }

    Transform GetClosestEnemy(GameObject[] planets)
    {
        Transform tMin = null;
        float minDist = Mathf.Infinity;
        Vector3 currentPos = transform.position;
        foreach (GameObject t in planets)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist < minDist)
            {
                tMin = t.transform;
                minDist = dist;
            }
        }

        return tMin;
    }

    void Update()
    {
        if (target == null)
        {
            if (enemy == false)
            {
                planeta = GameObject.FindGameObjectsWithTag("EnemyPlanet");
                planetn = GameObject.FindGameObjectsWithTag("NeutralPlanet");
            }
            if (enemy == true)
            {
                planeta = GameObject.FindGameObjectsWithTag("FriendlyPlanet");
                planetn = GameObject.FindGameObjectsWithTag("NeutralPlanet");
            }
            index = Random.Range(0, planeta.Length);

            //Randomenemy \/
            //planet = planeta[index];

            //closest enemy \/
            planet = GetClosestEnemy(planeta).gameObject;
            //planet = GetClosestEnemy(planetn).gameObject;

            target = planet.transform;
            //Destroy(gameObject);
            return;
        }


        Vector2 dir = target.position - this.transform.position;
        this.transform.up = target.position - this.transform.position;

        if (dir.magnitude <= 0.2f)
        {
           
            enem = target.gameObject.GetComponent<enemyPlanetScript>();

            if (!enemy) {
                if (planet.tag == "EnemyPlanet")
                {
                    enem.health -= unitd.UnitDamage;
                    Destroy(this.gameObject);
                }

                if(planet.tag == "FriendlyPlanet") {
                    enemyPlanetScript.ResourceLeft += unitd.cost;
                    Destroy(this.gameObject);
                }
                if(planet.tag == "NeutralPlanet")
                {
                    enemyPlanetScript.badgoodlasthit = true;
                    enem.health -= unitd.UnitDamage;
                    Destroy(this.gameObject);
                }
            }

            if (enemy)
            {
                if (planet.tag == "EnemyPlanet")
                {
                    AIplanets.resourcesL += unitd.cost;
                    Destroy(this.gameObject);
                }

                if (planet.tag == "NeutralPlanet")
                {
                    enemyPlanetScript.badgoodlasthit = false;
                    enem.health -= unitd.UnitDamage;
                    Destroy(this.gameObject);
                }
                if (planet.tag == "FriendlyPlanet")
                {
                    enem.health -= unitd.UnitDamage;

                    Destroy(this.gameObject);
                }
            }

            //Enemy en = target.gameObject.GetComponent<Enemy>();
            //if (en != null)
            //{
            //    if (Damage)
            //    {
            //        en.health -= Mathf.Max(en.health * damage, 20f);
            //    }
            //    else
            //    {
            //        en.health -= damage;
            //    }
            //}

            //Destroy(gameObject);
        }
        else
        {
            this.transform.Translate(dir.normalized * unitd.speed * Time.deltaTime, Space.World);
        }

    }


}
