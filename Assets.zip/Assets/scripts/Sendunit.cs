﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Sendunit : MonoBehaviour {

    public AIplanets AI;
    public Transform start;

    public void SendUnit(GameObject sendingunit)
    {
        if(Resourcemain.Resources >= sendingunit.GetComponent<unit>().cost) {

            sendingunit.GetComponent<UnitScript>().enemy = false;

            Instantiate(sendingunit, start.position + 
                new Vector3(Random.Range(-0.3f, 0.3f), Random.Range(-0.3f, 0.3f),0), new Quaternion(0,0,0,0));
        
            Resourcemain.Resources -= sendingunit.GetComponent<unit>().cost;

        }
    }

    public void SendUnitAI(GameObject sendingunit, Transform startplanet)
    {
        if (AIplanets.resources >= sendingunit.GetComponent<unit>().cost)
        {
            sendingunit.GetComponent<UnitScript>().enemy = true;
            Instantiate(sendingunit, startplanet.position +
                new Vector3(Random.Range(-0.3f, 0.3f), Random.Range(-0.3f, 0.3f), 0), new Quaternion(0, 0, 0, 0));

            

             AIplanets.resources -= sendingunit.GetComponent<unit>().cost;

        }
    }

}
