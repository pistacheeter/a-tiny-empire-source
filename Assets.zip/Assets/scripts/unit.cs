﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//[System.Serializable]
public class unit : MonoBehaviour {

    public GameObject Object;
    public GameObject par;

    public int UnitDamage = 2;
    public int cost = 1;
    public float speed = 2;
    public float damage = 10f;
    

    public string UnitName = "medium";
}
